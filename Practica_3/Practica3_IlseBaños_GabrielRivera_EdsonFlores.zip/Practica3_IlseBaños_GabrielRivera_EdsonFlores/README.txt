Practica 3

Ilse Andrea Baños Macila - 321173988
Flores Arriola Edson Rafael - 423118018
Gabriel Eduardo Rivera Machuca - 321057608