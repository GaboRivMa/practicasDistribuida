Practica 1
Ilse Andrea Baños Macila - 321173988
Gabriel Eduardo Rivera Machuca - 321057608